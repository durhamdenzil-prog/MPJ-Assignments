<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt"  prefix="fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Employee List</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', sans-serif; background: #f0f4f8; padding: 40px 20px; }
        .container { max-width: 1000px; margin: auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        h2 { color: #2d3748; font-size: 24px; }
        .btn { padding: 10px 22px; border-radius: 7px; font-size: 14px; font-weight: 600;
               text-decoration: none; border: none; cursor: pointer; }
        .btn-primary { background: #4f80ff; color: white; }
        .btn-primary:hover { background: #3a66e0; }
        .btn-edit   { background: #f6ad55; color: white; padding: 6px 14px; border-radius: 5px;
                      text-decoration: none; font-size: 13px; font-weight: 600; }
        .btn-delete { background: #fc8181; color: white; padding: 6px 14px; border-radius: 5px;
                      border: none; cursor: pointer; font-size: 13px; font-weight: 600; }
        .btn-edit:hover   { background: #ed8936; }
        .btn-delete:hover { background: #e53e3e; }
        table { width: 100%; border-collapse: collapse; background: white;
                border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        thead tr { background: #4f80ff; color: white; }
        th { padding: 14px 16px; text-align: left; font-size: 14px; font-weight: 600; }
        td { padding: 13px 16px; color: #4a5568; font-size: 14px; border-bottom: 1px solid #f0f4f8; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #f7faff; }
        .no-data { text-align: center; padding: 40px; color: #a0aec0; }
        .badge { display: inline-block; padding: 3px 10px; border-radius: 12px;
                 font-size: 12px; font-weight: 600; background: #ebf4ff; color: #4f80ff; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h2>&#128188; Employee Records
            <span style="font-size:14px; color:#718096; font-weight:400;">
                (${fn:length(employeeList)} total)
            </span>
        </h2>
        <a href="${pageContext.request.contextPath}/employees?action=new" class="btn btn-primary">
            + Add Employee
        </a>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Department</th>
                <th>Salary</th>
                <th>Join Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <c:choose>
                <c:when test="${empty employeeList}">
                    <tr><td colspan="8" class="no-data">No employees registered yet.</td></tr>
                </c:when>
                <c:otherwise>
                    <c:forEach var="emp" items="${employeeList}" varStatus="s">
                        <tr>
                            <td>${s.count}</td>
                            <td><strong>${emp.firstName} ${emp.lastName}</strong></td>
                            <td>${emp.email}</td>
                            <td>${emp.phone}</td>
                            <td><span class="badge">${emp.department}</span></td>
                            <td>₹<fmt:formatNumber value="${emp.salary}" pattern="#,##0.00"/></td>
                            <td>${emp.joinDate}</td>
                            <td>
                                <a href="${pageContext.request.contextPath}/employees?action=edit&id=${emp.id}"
                                   class="btn-edit">Edit</a>
                                &nbsp;
                                <form method="post" action="${pageContext.request.contextPath}/employees"
                                      style="display:inline"
                                      onsubmit="return confirm('Delete ${emp.firstName} ${emp.lastName}?')">
                                    <input type="hidden" name="action" value="delete_post">
                                    <button type="button" class="btn-delete"
                                            onclick="if(confirm('Delete ${emp.firstName}?')) location.href='${pageContext.request.contextPath}/employees?action=delete&id=${emp.id}'">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    </c:forEach>
                </c:otherwise>
            </c:choose>
        </tbody>
    </table>
</div>
</body>
</html>