<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${empty employee ? 'Add' : 'Edit'} Employee</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', sans-serif; background: #f0f4f8; padding: 40px 20px; }
        .container { max-width: 600px; margin: auto; }
        h2 { color: #2d3748; margin-bottom: 24px; font-size: 24px; }
        .card { background: white; border-radius: 12px; padding: 36px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        .form-group { margin-bottom: 18px; }
        label { display: block; color: #4a5568; font-weight: 600;
                margin-bottom: 6px; font-size: 14px; }
        input, select { width: 100%; padding: 10px 14px; border: 1.5px solid #e2e8f0;
                        border-radius: 7px; font-size: 15px; color: #2d3748;
                        transition: border 0.2s; outline: none; }
        input:focus, select:focus { border-color: #4f80ff; }
        .row { display: flex; gap: 16px; }
        .row .form-group { flex: 1; }
        .btn-row { display: flex; gap: 12px; margin-top: 24px; }
        .btn { padding: 11px 28px; border: none; border-radius: 7px;
               font-size: 15px; font-weight: 600; cursor: pointer; text-decoration: none;
               display: inline-block; text-align: center; }
        .btn-primary { background: #4f80ff; color: white; }
        .btn-primary:hover { background: #3a66e0; }
        .btn-secondary { background: #e2e8f0; color: #4a5568; }
        .btn-secondary:hover { background: #cbd5e0; }
    </style>
</head>
<body>
<div class="container">
    <h2>${empty employee ? '➕ Register New Employee' : '✏️ Edit Employee'}</h2>
    <div class="card">
        <form action="${pageContext.request.contextPath}/employees" method="post">
            <input type="hidden" name="action" value="${empty employee ? 'insert' : 'update'}">
            <c:if test="${not empty employee}">
                <input type="hidden" name="id" value="${employee.id}">
            </c:if>

            <div class="row">
                <div class="form-group">
                    <label>First Name *</label>
                    <input type="text" name="firstName" value="${employee.firstName}"
                           required maxlength="50" placeholder="John">
                </div>
                <div class="form-group">
                    <label>Last Name *</label>
                    <input type="text" name="lastName" value="${employee.lastName}"
                           required maxlength="50" placeholder="Doe">
                </div>
            </div>

            <div class="form-group">
                <label>Email Address *</label>
                <input type="email" name="email" value="${employee.email}"
                       required maxlength="100" placeholder="john.doe@company.com">
            </div>

            <div class="row">
                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone" value="${employee.phone}"
                           maxlength="15" placeholder="+91-9876543210">
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select name="department">
                        <option value="">-- Select --</option>
                        <c:forEach var="dept" items="${['Engineering','HR','Finance','Marketing','Operations','Sales']}">
                            <option value="${dept}" ${employee.department == dept ? 'selected' : ''}>${dept}</option>
                        </c:forEach>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="form-group">
                    <label>Salary (₹)</label>
                    <input type="number" name="salary" value="${employee.salary}"
                           min="0" step="0.01" placeholder="50000">
                </div>
                <div class="form-group">
                    <label>Join Date *</label>
                    <input type="date" name="joinDate" value="${employee.joinDate}" required>
                </div>
            </div>

            <div class="btn-row">
                <button type="submit" class="btn btn-primary">
                    ${empty employee ? 'Register Employee' : 'Update Employee'}
                </button>
                <a href="${pageContext.request.contextPath}/employees?action=list"
                   class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>