package com.employee.servlet;

import com.employee.dao.EmployeeDAO;
import com.employee.model.Employee;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

/**
 * ListEmployeeServlet
 * URL: /listEmployees
 * Fetches all employees from DB and forwards to list.jsp
 */
@WebServlet("/listEmployees")
public class ListEmployeeServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        EmployeeDAO dao = new EmployeeDAO();
        List<Employee> employees = dao.getAllEmployees();

        req.setAttribute("employees", employees);
        req.getRequestDispatcher("list.jsp").forward(req, res);
    }
}
