CREATE DATABASE employeedb;
USE employeedb;

CREATE TABLE employees (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    first_name  VARCHAR(50)  NOT NULL,
    last_name   VARCHAR(50)  NOT NULL,
    email       VARCHAR(100) NOT NULL UNIQUE,
    phone       VARCHAR(15),
    department  VARCHAR(50),
    salary      DOUBLE,
    join_date   DATE
);