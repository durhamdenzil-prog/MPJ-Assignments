<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Employee Registration System</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', sans-serif; background: #f0f4f8; display: flex;
               justify-content: center; align-items: center; height: 100vh; }
        .card { background: white; padding: 50px 60px; border-radius: 12px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; }
        h1 { color: #2d3748; margin-bottom: 10px; font-size: 28px; }
        p  { color: #718096; margin-bottom: 30px; }
        a.btn { display: inline-block; background: #4f80ff; color: white;
                padding: 14px 36px; border-radius: 8px; text-decoration: none;
                font-size: 16px; font-weight: 600; transition: background 0.2s; }
        a.btn:hover { background: #3a66e0; }
    </style>
</head>
<body>
    <div class="card">
        <h1>&#128188; Employee Registration</h1>
        <p>Manage your company's employee records with ease.</p>
        <a class="btn" href="${pageContext.request.contextPath}/employees?action=list">
            View All Employees
        </a>
    </div>
</body>
</html>