package com.emp.servlet;

import com.emp.dao.EmployeeDAO;
import com.emp.model.Employee;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private EmployeeDAO dao = new EmployeeDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "new":
                req.getRequestDispatcher("/employee-form.jsp").forward(req, resp);
                break;
            case "edit":
                int editId = Integer.parseInt(req.getParameter("id"));
                Employee editEmp = dao.getEmployeeById(editId);
                req.setAttribute("employee", editEmp);
                req.getRequestDispatcher("/employee-form.jsp").forward(req, resp);
                break;
            case "delete":
                int delId = Integer.parseInt(req.getParameter("id"));
                dao.deleteEmployee(delId);
                resp.sendRedirect(req.getContextPath() + "/employees?action=list");
                break;
            default:
                List<Employee> empList = dao.getAllEmployees();
                req.setAttribute("employeeList", empList);
                req.getRequestDispatcher("/employee-list.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        String firstName  = req.getParameter("firstName");
        String lastName   = req.getParameter("lastName");
        String email      = req.getParameter("email");
        String phone      = req.getParameter("phone");
        String department = req.getParameter("department");
        double salary     = Double.parseDouble(req.getParameter("salary"));
        Date joinDate     = Date.valueOf(req.getParameter("joinDate"));

        Employee emp = new Employee();
        emp.setFirstName(firstName);
        emp.setLastName(lastName);
        emp.setEmail(email);
        emp.setPhone(phone);
        emp.setDepartment(department);
        emp.setSalary(salary);
        emp.setJoinDate(joinDate);

        if ("insert".equals(action)) {
            dao.addEmployee(emp);
        } else if ("update".equals(action)) {
            emp.setId(Integer.parseInt(req.getParameter("id")));
            dao.updateEmployee(emp);
        }

        resp.sendRedirect(req.getContextPath() + "/employees?action=list");
    }
}