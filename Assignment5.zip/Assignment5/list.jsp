<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.employee.model.Employee, java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Employees</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            padding: 30px 20px;
        }

        h2 {
            color: #1a237e;
            margin-bottom: 20px;
            text-align: center;
        }

        .container { max-width: 900px; margin: 0 auto; }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }

        .top-bar span { color: #555; font-size: 0.9rem; }

        a.btn {
            display: inline-block;
            background: #1a237e;
            color: white;
            text-decoration: none;
            padding: 8px 18px;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        a.btn:hover { background: #283593; }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }

        thead { background: #1a237e; color: #fff; }
        thead th { padding: 14px 16px; text-align: left; font-size: 0.9rem; }

        tbody tr { border-bottom: 1px solid #f0f2f5; }
        tbody tr:last-child { border-bottom: none; }
        tbody tr:hover { background: #e8eaf6; }

        tbody td { padding: 12px 16px; font-size: 0.92rem; color: #333; }

        .badge {
            background: #e8eaf6;
            color: #1a237e;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
            font-size: 1rem;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>&#128203; Employee Records</h2>

    <%
        List<Employee> employees = (List<Employee>) request.getAttribute("employees");
        int count = (employees != null) ? employees.size() : 0;
    %>

    <div class="top-bar">
        <span>Total Employees: <strong><%= count %></strong></span>
        <a href="index.jsp" class="btn">&#43; Register New</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Department</th>
                <th>Salary (&#8377;)</th>
            </tr>
        </thead>
        <tbody>
        <% if (employees == null || employees.isEmpty()) { %>
            <tr><td colspan="6" class="no-data">No employees registered yet.</td></tr>
        <% } else {
               int sr = 1;
               for (Employee emp : employees) { %>
            <tr>
                <td><%= sr++ %></td>
                <td><%= emp.getName() %></td>
                <td><%= emp.getEmail() %></td>
                <td><%= emp.getPhone() %></td>
                <td><span class="badge"><%= emp.getDepartment() %></span></td>
                <td><%= String.format("%,.2f", emp.getSalary()) %></td>
            </tr>
        <% }} %>
        </tbody>
    </table>
</div>
</body>
</html>
